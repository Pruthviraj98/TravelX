<?php
session_start();
//connect to database
$db=mysqli_connect("127.0.0.1:3307","root","","Train_Reservation");
if(isset($_POST['msgsubmit']))
{
    $name=mysqli_real_escape_string($db,$_POST['Name']);
    $email=mysqli_real_escape_string($db,$_POST['Email']);
    $message=mysqli_real_escape_string($db,$_POST['Message']);
	        $sql="INSERT INTO `message`(`NAME`, `EMAIL`, `MESSAGE`) VALUES ('$name','$email','$message')";
            mysqli_query($db,$sql);
            $_SESSION['message']="YOUR MESSAGE IS SENT!!";
            $_SESSION['name']=$name;
			unset($_POST['msgsubmit']);
			
            header("location:/train/homepage.php");  //redirect home page
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>TravelX</title>
<link rel="shortcut icon" type="image/x-icon" href="mapmarker.ico" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Excavate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">
<link href="css/font-awesome.css" rel="stylesheet">   <!-- font-awesome icons -->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<link rel="stylesheet" href="css/percircle.css">
<link rel="stylesheet" href="css/lightbox.css"> <!-- lightbox css -->
<!-- //Custom Theme files -->
<!-- web-fonts -->
<link href='//fonts.googleapis.com/css?family=Cinzel+Decorative:400,700,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- //web-fonts -->
</head>
<body>
	<!-- header -->
	<div class="headerw3-agile">
		<div class="header-w3top"><!-- header-top -->
			<ul>
				<li><i class="fa fa-phone"></i> +91 9877587845 </li>
				<li><a href="mailto:example@mail.com"><i class="fa fa-envelope-o"></i>  mail@TravelX.com</a></li>
				<li><i class="fa fa-map-marker"></i> Chennai, Tamilnadu, India </li>
			</ul>
			<div class="clearfix"> </div>
		</div>
		<div class="header-w3mdl"><!-- header-two -->
			<div class="container">
				<div class="agileits-logo navbar-left">
					<h1><i class="fa fa-map-marker w3-margin-right"></i>&nbsp; <a href="/train/mainpage.html">TravelX</a></h1>
				</div>
				<div class="agileits-hdright nav navbar-nav navbar-right">
					<div class="social-icon">
						<a href="#" class="si-agileits twitter"><i class="fa fa-twitter"></i></a>
						<a href="#" class="si-agileits facebook"><i class="fa fa-facebook"></i></a>
						<a href="#" class="si-agileits google"><i class="fa fa-google-plus"></i></a>
						<a href="#" class="si-agileits dribbble"><i class="fa fa-dribbble"></i></a>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //header -->
	<!-- banner -->
	<div class="w3ls-banner">
		<!-- banner-text -->
		<div class="banner-text">
			<div class="flexslider">
				<ul class="slides">
					<li>

						<h2>CONTACT US</h2>
						<span><i class="fa fa-s
							quare-o" aria-hidden="true"></i><i class="fa fa-square-o" aria-hidden="true"></i><i class="fa fa-square-o" aria-hidden="true"></i></span>

					</li>
					<li>
						<h3>WRITE TO US</h3>
						<span><i class="fa fa-square-o" aria-hidden="true"></i><i class="fa fa-square-o" aria-hidden="true"></i><i class="fa fa-square-o" aria-hidden="true"></i></span>

					</li>
				</ul>
			</div>
		</div>
		<!-- //banner-text -->
	</div>
	<!-- //banner -->
	<!-- services -->
	<div id="services" class="services">
		<div class="container">
			<h3 class="w3title">Services</h3>
			<div class="services-w3lsrow">
				<div class="col-md-3 col-sm-3 col-xs-6 services-grids">
					<i class="fa fa-calendar icon" aria-hidden="true"></i>
					<h4><a href="plan.html">Book Yor Tickets Now</a></h4>
					<p>Visit to India's beautiful places-plan your holidays now!!</p>
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6 services-grids">
					<div class="w3agile-servs-img">
						<i class="fa fa-bed icon" aria-hidden="true"></i>
						<h4><a href="hotel.html">Book your stay </a></h4>
						<p>Book the rooms at the some of the best hotels in your destination</p>
					</div>
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6 services-grids">
					<div class="w3agile-servs-img">
						<i class="fa fa-thumbs-up icon" aria-hidden="true"></i>
						<h4><a href="rate.html">Rate Us</a></h4>
						<p>Satisfaction of the Customer is the only goal of our's</p>
					</div>
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6 services-grids">
					<div class="w3agile-servs-img">
						<i class="fa fa-train icon" aria-hidden="true"></i>
						<h4><a href="offices.html">Our Stations</a></h4>
						<p>We are expanding to connect people all around India</p>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //services -->
	<!-- about -->
	<div id="about" class="about">
		<div class="container">
			<div class="about-agileinfo">
				<div class="col-sm-3 about-grids about-grids2">
					<img src="images/img3.jpg" class="img-responsive" alt=""/>
				</div>
				<div class="col-sm-6 about-text">
					<h5>ABOUT US</h5>
					<h4>Who we are!</h4>
					<p> TravelX.com is the website founded by four B-tech students of VIT UNIVERSITY. It is the website that includes the booking of every facility during his/her
					travel on rails.</p>
					<h4>So, Why Book With Us?</h4>
					<p> The website deals with the booking from the Railway ticket to Food on rails, and also booking the accomodation at the destination and billing this altogether at once
					without any complexities that are regularly faced by the customer.</p>
				</div>
				<div class="col-sm-3 about-grids about-grids2">
					<img src="images/img2.jpg" class="img-responsive" alt=""/>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //about -->

	<!-- subscribe -->
	<div class="sub-agileitsinfo">
		<div class="subscribe wthree-sub">
			<div class="container">
				<h4>Subscribe Now to get the latest offers and discounts on booking the Tickets!!</h4>
				<form action="#" method="post">
					<input type="email" name="email" placeholder="Enter your Email..." required="">
					<input type="submit" value="Subscribe">
					<div class="clearfix"> </div>
				</form>
			</div>
		</div>
	</div>
	<!-- //subscribe -->
	<!-- contact -->
	<div id="contact" class="map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3023.9503398796587!2d-73.9940307!3d40.719109700000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a27e2f24131%3A0x64ffc98d24069f02!2sCANADA!5e0!3m2!1sen!2sin!4v1441710758555"></iframe>
		<div class="contact">
			<div class="container">
				<h3 class="w3title">Contact Us</h3>
				<div class="contact-grids">
					<div class="col-sm-6 w3ls-address">
						<h4>Get in touch with us</h4>
						<p class="cnt-p">It is your most promising website to book your tickets making sure the safeties and all the amenities be present during your time of travel</p>
						<p class="address">VIT-UNIVERSITY <br> Chennai, Tamilnadu, India </p>
						<p><b>Telephone</b> : +919798899887</p>
						<p><b>FAX</b> : +18 888 4444</p>
						<p><b>Email</b> : <a href="mailto:example@mail.com">mail@TravelX.com</a></p>
						<div class="social-icon contact-w3lsicns">
							<a href="#" class="si-agileits twitter"><i class="fa fa-twitter"></i></a>
							<a href="#" class="si-agileits facebook"><i class="fa fa-facebook"></i></a>
							<a href="#" class="si-agileits google"><i class="fa fa-google-plus"></i></a>
							<a href="#" class="si-agileits dribbble"><i class="fa fa-dribbble"></i></a>
						</div>
					</div>
					<h2>
					<?php
					if(isset($_SESSION['message']))
						{
							echo "<div id='error_msg'>".$_SESSION['message']."</div>";
							unset($_SESSION['message']);
						}
					?>
					</h2>
					<div class="col-sm-6 contact-form">
						<form action="contact.php" method="post">
							<input type="text" name="Name" placeholder="First Name" required="">
							<input class="email" name="Last Name" type="text" placeholder="Last Name" required="">
							<input type="text" name="Number" placeholder="Mobile Number" required="">
							<input class="email" name="Email" type="text" placeholder="Email" required="">
							<textarea name="Message" placeholder="Message" required=""></textarea>
							<input type="submit" value="SUBMIT" name="msgsubmit">
						</form>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<!-- //map -->
	</div>
	<!-- //contact -->
	<!-- copy rights start here -->
	<div class="copy-w3right">
		<div class="container">
			<p>© 2017 TravelX. All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
		</div>
	</div>
	<!-- //copy right end here -->
	<!-- js -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- FlexSlider -->
	<script defer src="js/jquery.flexslider.js"></script>
	<script type="text/javascript">
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	</script>
	<!-- End-slider-script -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- start-smooth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){
					event.preventDefault();

			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
	</script>
	<!-- //end-smooth-scrolling -->
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
			};
			*/

			$().UItoTop({ easingType: 'easeOutQuart' });

		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="js/percircle.js"></script>
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
</body>
</html>
